from django.urls import path
# from django.conf.urls import url
from django.contrib import admin
# from .views import HomePage
from . import views
# Fo handling 404 page
from django.urls import include, path

urlpatterns = [
    path('', views.LoginView.as_view(), name='login'),
    path('logout/', views.LogoutView.as_view(), name='logout'),
    path('home/', views.home.as_view(), name='home'),
    path('devices/', views.devices.as_view(), name='devices'),
    path('configure/', views.ConfigureView.as_view(), name='configure'),
    path('verify-config/', views.VerifyConfigView.as_view(), name='verify_config'),
    path('log/', views.log.as_view(), name='log'),  
    path('404/', views.error_404_view, name='404')
]