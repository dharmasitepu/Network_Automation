from django.contrib.auth import authenticate, login, logout #for login
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.shortcuts import render, redirect
from django.views import View
from datetime import datetime
import paramiko
import requests
import time

class HomePageDataProviderImpl:
    @staticmethod
    def get_all_devices():
        api_url = "http://127.0.0.1/api/devices/"
        response = requests.get(api_url)
        if response.status_code == 200:
            return response.json()
        else:
            return []

    @staticmethod
    def get_all_logs():
        api_url = "http://127.0.0.1/api/logs/"
        response = requests.get(api_url)
        if response.status_code == 200:
            return response.json()
        else:
            return []

class LoginView(View):
    def get(self, request):
        return render(request, 'login.html')
    
    def post(self, request):
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html')

@method_decorator(login_required, name='dispatch')
class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login')

@method_decorator(login_required, name='dispatch')
class home(View):
    def __init__(self, data_provider=HomePageDataProviderImpl()):
        self.data_provider = data_provider

    def get(self, request):
        all_devices = self.data_provider.get_all_devices()
        cisco_devices = [device for device in all_devices if device.get('vendor') == 'cisco']
        mikrotik_devices = [device for device in all_devices if device.get('vendor') == 'mikrotik']
        linux_devices = [device for device in all_devices if device.get('vendor') == 'linux']

        last_events = self.data_provider.get_all_logs()[:10]

        context = {
            "all_device": len(all_devices),
            "cisco_device": len(cisco_devices),
            "mikrotik_device": len(mikrotik_devices),
            "linux_device": len(linux_devices),
            "last_event": last_events,
        }

        return render(request, "home.html", context)

@method_decorator(login_required, name='dispatch')
class devices(View):
    def get(self, request):
        all_devices = HomePageDataProviderImpl.get_all_devices()

        context = {
            'all_device': all_devices
        }

        return render(request, 'devices.html', context)

@method_decorator(login_required, name='dispatch')
class ConfigureView(View):
    def get(self, request):
        devices = HomePageDataProviderImpl.get_all_devices()
        context = {
            'devices': devices,
            'mode': 'Configure',
        }
        return render(request, 'config.html', context)
    

def post(self, request):
    selected_device_ids = request.POST.getlist('device')
    mikrotik_commands = request.POST.get('mikrotik_command', '').splitlines()
    cisco_commands = request.POST.get('cisco_command', '').splitlines()
    linux_commands = request.POST.get('linux_command', '').splitlines()

    logs = []

    devices = HomePageDataProviderImpl.get_all_devices()

    for device_id in selected_device_ids:
        device = next((dev for dev in devices if dev['id'] == int(device_id)), None)
        if device is None:
            log = {
                'target': f"Device ID {device_id}",
                'action': 'Configure',
                'status': 'Error',
                'time': datetime.now().isoformat(),
                'messages': f"Device with ID {device_id} not found",
            }
            logs.append(log)
            continue

        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            ssh_client.connect(
                hostname=device['ip_address'],
                username=device['username'],
                password=device['password'],
                port=device['ssh_port'],
            )

            try:
                if device['vendor'].lower() == 'cisco':
                    conn = ssh_client.invoke_shell()
                    conn.send("conf t\n")
                    for cmd in cisco_commands:
                        conn.send(cmd + "\n")
                        time.sleep(1)
                elif device['vendor'].lower() == 'mikrotik':
                    for cmd in mikrotik_commands:
                        ssh_client.exec_command(cmd)
                elif device['vendor'].lower() == 'linux':
                    for cmd in linux_commands:
                        stdin, stdout, stderr = ssh_client.exec_command(cmd)

                log = {
                    'target': device['ip_address'],
                    'action': 'Configure',
                    'status': 'Success',
                    'time': datetime.now().isoformat(),
                    'messages': 'No error',
                }
                logs.append(log)
            except Exception as cmd_ex:
                log = {
                    'target': device['ip_address'],
                    'action': 'Configure',
                    'status': 'Error',
                    'time': datetime.now().isoformat(),
                    'messages': str(cmd_ex),
                }
                logs.append(log)
            finally:
                ssh_client.close()

        except Exception as conn_ex:
            log = {
                'target': device['ip_address'],
                'action': 'Configure',
                'status': 'Error',
                'time': datetime.now().isoformat(),
                'messages': str(conn_ex),
            }
            logs.append(log)

    # Simpan atau tampilkan logs untuk debugging
    for log in logs:
        print(log)  # Atau simpan log ke file atau database

    return redirect('home')

@method_decorator(login_required, name='dispatch')
class VerifyConfigView(View):
    def get(self, request):
        devices = HomePageDataProviderImpl.get_all_devices()
        context = {
            'devices': devices,
            'mode': 'Verify Config'
        }
        return render(request, 'config.html', context)

    def post(self, request):
        devices = HomePageDataProviderImpl.get_all_devices()
        result = []
        selected_device_ids = request.POST.getlist('device')
        mikrotik_commands = request.POST['mikrotik_command'].splitlines()
        cisco_commands = request.POST['cisco_command'].splitlines()
        linux_commands = request.POST['linux_command'].splitlines()

        logs = []

        for device_id in selected_device_ids:
            try:
                device = next(dev for dev in devices if dev['id'] == int(device_id))
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(
                    hostname=device['ip_address'],
                    username=device['username'],
                    password=device['password'],
                    port=device['ssh_port'],
                )

                if device['vendor'].lower() == 'mikrotik':
                    for cmd in mikrotik_commands:
                        stdin, stdout, stderr = ssh_client.exec_command(cmd)
                        result.append("Result on {}: {}".format(device['ip_address'], cmd))
                        result.append(stdout.read().decode())
                elif device['vendor'].lower() == 'cisco':
                    conn = ssh_client.invoke_shell()
                    conn.send('terminal length 0\n')
                    for cmd in cisco_commands:
                        result.append("Result on {}: {}".format(device['ip_address'], cmd))
                        conn.send(cmd + "\n")
                        time.sleep(1)
                        output = conn.recv(65535)
                        result.append(output.decode())
                elif device['vendor'].lower() == 'linux':
                    for cmd in linux_commands:
                        stdin, stdout, stderr = ssh_client.exec_command(cmd)
                        result.append("Result on {} for command: {}".format(device['ip_address'], cmd))
                        result.append(stdout.read().decode())
                log = {
                    'target': device['ip_address'],
                    'action': 'Verify Config',
                    'status': 'Success',
                    'time': datetime.now().isoformat(),
                    'messages': 'No error',
                }
                logs.append(log)
            except Exception as e:
                log = {
                    'target': device['ip_address'],
                    'action': 'Verify Config',
                    'status': 'Error',
                    'time': datetime.now().isoformat(),
                    'messages': str(e),
                }
                logs.append(log)
        
        result = '\n'.join(result)
        return render(request, 'verify_result.html', {'result': result})

@method_decorator(login_required, name='dispatch')
class log(View):
    def get(self, request):
        logs = HomePageDataProviderImpl.get_all_logs()
        context = {
            'logs': logs
        }

        return render(request, 'log.html', context)

def error_404_view(request, exception):
    return render(request, '404.html')
