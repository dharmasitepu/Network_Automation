from django.urls import path
# from django.conf.urls import url
from django.contrib import admin
# from .views import HomePage
from . import views
# Fo handling 404 page
from django.urls import include, path


urlpatterns = [
    path('api/devices/', views.DeviceList.as_view(), name='device-list-api'),
    path('api/logs/', views.LogList.as_view(), name='log-list-api'),
    path('api/home-data/', views.HomeDataView.as_view(), name='home-data-api'),
    path('api/home/', views.HomeView.as_view(), name='home-api'),
    path('api/devices/', views.DeviceListView.as_view(), name='devices-api'),
    path('api/configure/', views.ConfigureView.as_view(), name='configure-api'),
    path('api/verify-config/', views.VerifyConfigView.as_view(), name='verify-config-api'),
]
