from typing import ContextManager # For context handler
from django.db import connection # socket to django sqlite3
from django.core.checks import messages # Get error data from core
from django.shortcuts import get_object_or_404, redirect, render, HttpResponse # For http responds
from paramiko.pkey import OPENSSH_AUTH_MAGIC # Pkey for OpenSSH
from .models import Device, Log # Import from Models
from datetime import datetime # For datetime loging record
import paramiko # For ssh remote to router
import time # For time loging record
from django.views import View #class base view models for OOP
from django.views.generic import View  #class base view models for OOP
from django.contrib.auth import authenticate, login, logout #for login
from django.contrib.auth.decorators import login_required # for restrict other page access before login
from django.utils.decorators import method_decorator # for restrict other page access before login
from django.conf import settings # For handling 404 page
#Beloow For API
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import DeviceSerializer, LogSerializer
from django.urls import reverse

class DeviceList(APIView):
    def get(self, request):
        devices = Device.objects.all()
        serializer = DeviceSerializer(devices, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = DeviceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LogList(APIView):
    def get(self, request):
        logs = Log.objects.all()
        serializer = LogSerializer(logs, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = LogSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class HomePageDataProviderAPI(APIView):
    def get(self, request):
        data_provider = HomePageDataProviderImpl()
        context = {
            "all_device": data_provider.get_all_device_count(),
            "cisco_device": data_provider.get_cisco_device_count(),
            "mikrotik_device": data_provider.get_mikrotik_device_count(),
            "linux_device": data_provider.get_linux_device_count(),
            "last_event": data_provider.get_last_events(),
        }
        return Response(context)

@method_decorator(login_required, name='dispatch')
class LogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login')

@method_decorator(login_required, name='dispatch')
class HomeDataView(APIView):
    def get(self, request):
        data_provider = HomePageDataProviderImpl()
        context = {
            "all_device": data_provider.get_all_device_count(),
            "cisco_device": data_provider.get_cisco_device_count(),
            "mikrotik_device": data_provider.get_mikrotik_device_count(),
            "linux_device": data_provider.get_linux_device_count(),
            "last_event": data_provider.get_last_events(),
        }
        return Response(context)

@method_decorator(login_required, name='dispatch')
class HomeView(APIView):
    def get(self, request):
        data_provider = HomePageDataProviderImpl()
        context = {
            "all_device": data_provider.get_all_device_count(),
            "cisco_device": data_provider.get_cisco_device_count(),
            "mikrotik_device": data_provider.get_mikrotik_device_count(),
            "linux_device": data_provider.get_linux_device_count(),
            "last_event": data_provider.get_last_events(),
        }
        return render(request, "home.html", context)

@method_decorator(login_required, name='dispatch')
class DeviceListView(APIView):
    def get(self, request):
        devices = Device.objects.all()
        serializer = DeviceSerializer(devices, many=True)
        return Response(serializer.data)

@method_decorator(login_required, name='dispatch')
class ConfigureView(APIView):
    def get(self, request):
        devices = Device.objects.all()
        context = {
            'devices': DeviceSerializer(devices, many=True).data,
            'mode': 'Configure',
        }
        return render(request, 'config.html', context)
    
    def post(self, request):
        selected_device_ids = request.POST.getlist('device')
        mikrotik_commands = request.POST['mikrotik_command'].splitlines()
        cisco_commands = request.POST['cisco_command'].splitlines()
        linux_device = request.POST['linux_command'].splitlines()

        for device_id in selected_device_ids:
            try:
                device = get_object_or_404(Device, pk=device_id)
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(
                    hostname=device.ip_address,
                    username=device.username,
                    password=device.password,
                    port=device.ssh_port,
                )

                if device.vendor.lower() == 'cisco':
                    conn = ssh_client.invoke_shell()
                    conn.send("conf t\n")
                    for cmd in cisco_commands:
                        conn.send(cmd + "\n")
                        time.sleep(1)
                elif device.vendor.lower() == 'mikrotik':
                    for cmd in mikrotik_commands:
                        ssh_client.exec_command(cmd)
                elif device.vendor.lower() == 'linux':
                    for cmd in linux_device:
                        stdin, stdout, stderr = ssh_client.exec_command(cmd)

                log = Log(
                    target=device.ip_address,
                    action="Configure",
                    status="Success",
                    time=datetime.now(),
                    messages="No error",
                )
                log.save()
            except Exception as e:
                log = Log(
                    target=device.ip_address,
                    action="Configure",
                    status="Error",
                    time=datetime.now(),
                    messages=str(e),
                )
                log.save()
            finally:
                ssh_client.close()

        return redirect(reverse('home'))

@method_decorator(login_required, name='dispatch')
class VerifyConfigView(APIView):
    def get(self, request):
        devices = Device.objects.all()
        context = {
            'devices': DeviceSerializer(devices, many=True).data,
            'mode': 'Verify Config'
        }
        return render(request, 'config.html', context)

    def post(self, request):
        result = []
        selected_device_ids = request.POST.getlist('device')
        mikrotik_commands = request.POST['mikrotik_command'].splitlines()
        cisco_commands = request.POST['cisco_command'].splitlines()
        linux_device = request.POST['linux_command'].splitlines()

        for device_id in selected_device_ids:
            try:
                dev = get_object_or_404(Device, pk=device_id)
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh_client.connect(hostname=dev.ip_address,username=dev.username,password=dev.password,port=dev.ssh_port)

                if dev.vendor.lower() == 'mikrotik':
                    for cmd in mikrotik_commands:
                        stdin, stdout, stderr = ssh_client.exec_command(cmd)
                        result.append("Result on {}".format(dev.ip_address))
                        result.append(stdout.read().decode())
                elif dev.vendor.lower() == 'cisco': 
                    conn = ssh_client.invoke_shell()
                    conn.send('terminal length 0\n')
                    for cmd in cisco_commands:
                        result.append("Result on {}".format(dev.ip_address))
                        conn.send(cmd + "\n")
                        time.sleep(1)
                        output = conn.recv(65535)
                        result.append(output.decode())
                elif dev.vendor.lower() == 'linux':  
                    for cmd in linux_device:
                        stdin, stdout, stderr = ssh_client.exec_command(cmd)
                        result.append("Result on {} for command: {}".format(dev.ip_address, cmd))
                        result.append(stdout.read().decode())
                log = Log(target=dev.ip_address, action="Verify Config", status="Success", time=datetime.now(), messages="No error")
                log.save()
            except Exception as e:
                log = Log(target=dev.ip_address, action="Verify Config", status="Error", time=datetime.now(), messages=str(e))  
                log.save()

        result = '\n'.join(result)
        return render(request, 'verify_result.html', {'result': result})

@method_decorator(login_required, name='dispatch')
class LogListView(APIView):
    def get(self, request):
        logs = Log.objects.all().order_by('-id')
        serializer = LogSerializer(logs, many=True)
        return Response(serializer.data)

    def post(self, request):
        # Add logic for POST requests if needed
        pass

    def put(self, request):
        # Add logic for PUT requests if needed
        pass

    def delete(self, request):
        # Add logic for DELETE requests if needed
        pass